<?php
// Läs in datan säkert från $_POST
$name = isset($_POST["name"]) ? $_POST["name"] : "Gäst";
$choice = isset($_POST["choice"]) ? $_POST["choice"] : "övrigt";
?>
<!DOCTYPE html>
<html lang="sv">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tack – Alan Turing Portfolio</title>
  <meta name="description" content="Tack för ditt meddelande.">
  <link rel="stylesheet" href="css/style.css">
  <script src="js/script.js" defer></script>
</head>
<body>
  <header>
    <nav aria-label="Huvudmeny">
      <ul>
        <li><a href="index.html">Om mig</a></li>
        <li><a href="kompetenser.html">Kompetenser</a></li>
        <li><a href="projekt.html">Projekt</a></li>
        <li><a href="utbildning.html">Utbildning</a></li>
        <li><a href="ai.html">AI &amp; Etik</a></li>
        <li><a href="kontakt.html">Kontakt</a></li>
      </ul>
    </nav>
  </header>

  <main>
    <h1 class="page-title">Tack för ditt meddelande!</h1>
    <p class="page-text">
      Hej <strong><?php echo htmlspecialchars($name); ?></strong>, vi har tagit emot din förfrågan gällande ärendet: <em><?php echo htmlspecialchars($choice); ?></em>. Vi återkommer så snart som möjligt!
    </p>
  </main>

  <footer>
    <p>&copy; 2026 Alan Turing Portfolio</p>
  </footer>
</body>
</html>
