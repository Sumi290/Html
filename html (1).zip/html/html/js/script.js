// Filen finns och är inlänkad enligt kraven.
console.log("Script laddat för Alan Turing Portfolio");