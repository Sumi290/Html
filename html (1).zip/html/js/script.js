// Bekräfta att skriptet är inlänkat och körs på sidan
console.log("Script laddat för Alan Turing Portfolio");

// Vänta tills hela HTML-dokumentet har laddats
document.addEventListener('DOMContentLoaded', () => {
  initQuoteButton();
  initSkillsInteractivity();
  initContactForm();
  initProjectsInteractivity();
  initTimelineInteractivity();
});

/**
 * 1. Hanterar citat-knappen (index.html / Om mig)
 */
function initQuoteButton() {
  const quoteButton = document.querySelector('[data-js-action="show-quote"]');
  const quoteOutput = document.querySelector('[data-js-target="quote-box"]');

  if (!quoteButton || !quoteOutput) return;

  const quotes = {
    turing: "We can only see a short distance ahead, but we can see plenty there that needs to be done."
  };

  quoteButton.addEventListener('click', () => {
    const author = quoteButton.getAttribute('data-author');
    const quote = quotes[author] || "Ingen information tillgänglig.";
    quoteOutput.textContent = `"${quote}"`;
  });
}

/**
 * 2. Klickbara rader i kompetenstabellen (kompetenser.html)
 */
function initSkillsInteractivity() {
  const tableRows = document.querySelectorAll('.skills-table tbody tr');

  if (tableRows.length === 0) return;

  tableRows.forEach(row => {
    row.style.cursor = 'pointer';
    
    row.addEventListener('click', () => {
      tableRows.forEach(r => r.style.backgroundColor = '');
      row.style.backgroundColor = 'rgba(0, 0, 0, 0.05)';
    });
  });
}

/**
 * 3. Enkel validering av kontaktformuläret (kontakt.html)
 */
function initContactForm() {
  const contactForm = document.querySelector('.contact-form');

  if (!contactForm) return;

  contactForm.addEventListener('submit', (event) => {
    const nameInput = document.getElementById('name');
    const emailInput = document.getElementById('email');
    const messageInput = document.getElementById('message');

    if (!nameInput.value.trim() || !emailInput.value.trim() || !messageInput.value.trim()) {
      event.preventDefault();
      alert('Vänligen fyll i alla fält innan du skickar meddelandet.');
    }
  });
}

/**
 * 4. Hanterar projektinteraktioner (projekt.html)
 */
function initProjectsInteractivity() {
  const explainBtn = document.querySelector('[data-js-action="explain-model"]');
  const explainOutput = document.querySelector('[data-js-target="machine-explanation"]');

  if (explainBtn && explainOutput) {
    explainBtn.addEventListener('click', () => {
      const concept = explainBtn.getAttribute('data-concept');
      if (concept === 'turing-machine') {
        explainOutput.textContent = "Turingmaskinen läser, skriver och flyttar ett band med symboler fram och tillbaka enligt fasta regler – den matematiska grunden för alla moderna datorer.";
      }
    });
  }

  const statsBtn = document.querySelector('[data-js-action="show-stats"]');
  const statsOutput = document.querySelector('[data-js-target="stats-output"]');

  if (statsBtn && statsOutput) {
    statsBtn.addEventListener('click', () => {
      const machine = statsBtn.getAttribute('data-machine');
      if (machine === 'bombe') {
        statsOutput.textContent = "The Bombe kunde testa tusentals kombinationer parallellt och reducerade tiden för att knäcka Enigma-meddelanden från veckor till minuter.";
      }
    });
  }
}

/**
 * 5. Klickbara punkter i tidslinjen (utbildning.html)
 */
function initTimelineInteractivity() {
  const timelineItems = document.querySelectorAll('.timeline-list__item');

  if (timelineItems.length === 0) return;

  timelineItems.forEach(item => {
    item.style.cursor = 'pointer';
    item.title = 'Klicka för att markera';

    item.addEventListener('click', () => {
      timelineItems.forEach(i => {
        i.style.fontWeight = 'normal';
        i.style.paddingLeft = '0';
        i.style.borderLeft = 'none';
      });

      item.style.fontWeight = 'bold';
      item.style.paddingLeft = '0.5rem';
      item.style.borderLeft = '3px solid #333';
    });
  });
}